package com.mmm.Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
    public static final String USER = "PERFST14";
    public static final String PASSWORD = "Pa$$KovidTest@2020";
    public static final String URL = "http://sapgup101.mmm.com:50000/irj/portal";

    private WebDriver driver;
    private WebDriverWait wait;
    private By userName = By.id("logonuidfield");
    private By password = By.id("logonpassfield");
    private By loginButton = By.name("uidPasswordLogon");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, 20);
    }

    public void openSRMLoginPage() {
        driver.get(URL);
    }

    public void loginToSRM() {
        driver.manage().window().maximize();
        enterCredentials();
        pressLogin();

        wait.until(ExpectedConditions.titleContains("Universal Worklist"));
        wait.until(ExpectedConditions.or(
                ExpectedConditions.titleContains("Universal Worklist"), ExpectedConditions.titleContains("Shopping Cart")));
    }

    public boolean checkIfLoginNeeded() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(userName));
            // driver.findElement(userName);
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    private void enterCredentials() {
        driver.findElement(userName).sendKeys(USER);
        driver.findElement(password).sendKeys(PASSWORD);
    }

    private void pressLogin() {
        driver.findElement(loginButton).sendKeys(Keys.ENTER);
    }


}
