package com.mmm.Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;

public class ShoppingCartPage {

    private WebDriver driver;
    private WebDriverWait wait;
    private By lineItemDetailsArray = By.xpath("//tbody[contains(@id,'contentTBody')]//child::td//child::a[@title='-']//child::span");
    private By lineItemDetails = By.xpath("//tbody[contains(@id,'contentTBody')]//child::td//child::a[@title='-']//child::span[i]");
    private By approveBtn = By.xpath("//span[text()='Approve']");
    private By refreshBtn = By.xpath("//span[text()='Refresh']");

    public ShoppingCartPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(this.driver, 10);
    }

     public void showDetailsOfItems() {

        switchToShoppingCartWindow();

        List<WebElement> lineItems = driver.findElements(this.lineItemDetailsArray);
        int itemsAmount = lineItems.size();
        int instance = 0;
        StringBuffer sB = new StringBuffer("//tbody[contains(@id,'contentTBody')]//child::td//child::a[@title='-']//child::span[i]");

        for (int i = 1; i <= itemsAmount; i++) {
            lineItems = driver.findElements(this.lineItemDetailsArray);
            lineItems.get(instance).click();
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            takeScreenshot("Details line item" + i);
            instance++;
        }
    }

    public void approveSC() {
        System.out.println("approve button");
        driver.findElement(approveBtn).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(refreshBtn));
        driver.findElement(refreshBtn).click();
    }
    private void switchToShoppingCartWindow() {
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//iframe[@id='contentAreaFrame']")));
        driver.switchTo().frame("contentAreaFrame");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//iframe[@id='isolatedWorkArea']")));
        driver.switchTo().frame("isolatedWorkArea");
    }

    private void takeScreenshot(String name) {

        TakesScreenshot srcShot = ((TakesScreenshot) driver);
        File srcFile = srcShot.getScreenshotAs(OutputType.FILE);
        File destFile = new File("C:\\TEMP\\Projects\\SRMSeleniumPOC\\src\\Screenshots\\" + name + ".png");
        try {
            FileUtils.copyFile(srcFile, destFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
