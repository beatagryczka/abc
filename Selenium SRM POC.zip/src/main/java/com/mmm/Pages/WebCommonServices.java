package com.mmm.Pages;

import com.sun.java.swing.plaf.windows.resources.windows;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class WebCommonServices {
    private static WebDriver driver;
    private DesiredCapabilities capabilities;
    private static WebCommonServices instance;

    private WebCommonServices() {

        capabilities = DesiredCapabilities.internetExplorer();
        // commented because I have concern that this forces me log to SRM again when opening SC
        capabilities.setCapability("ensureCleanSession", true);
        capabilities.setCapability("enableElementCacheCleanup", true);
        capabilities.setCapability("nativeEvents", false);
        capabilities.setCapability("browserName", "internet explorer");
        capabilities.setCapability("ignoreZoomSetting", true);
        capabilities.setCapability("ignoreProtectedModeSettings", true);
        capabilities.setCapability("platform", Platform.WINDOWS);
        capabilities.setCapability("unexpectedAlertBehaviour", "accept");

        InternetExplorerOptions options = new InternetExplorerOptions(capabilities);
        this.driver = new InternetExplorerDriver(options);
    }

    public static WebCommonServices getInstance() {
        if (instance == null) {
            instance = new WebCommonServices();
        }
        return instance;
    }

    public void getNewestWindow() {
        String originalWindow = driver.getWindowHandle();
        List<String> windows = new ArrayList<String>(driver.getWindowHandles());

        boolean newWindowOpened = false;
        while (!newWindowOpened){
            windows = new ArrayList<String>(driver.getWindowHandles());
            newWindowOpened = windows.size() > 1 ? true: false;
        }
        ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
        System.out.println("Switching to last window...");
        for(String window:windows) {
            System.out.println(window);
        }
        driver.switchTo().window(windows.get(1));
        driver.manage().window().maximize();
    }

    /*    public void getNewestWindow() {
            Set<String> windowHandles;
            windowHandles = driver.getWindowHandles();
            String lastWindow = null;
            for (String s : windowHandles) {
                lastWindow = s;
                System.out.println(lastWindow);
            }
            ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
            System.out.println("Switching to last window...");
            driver.switchTo().window(lastWindow);
            driver.manage().window().maximize();
        }*/
    public WebDriver getDriver() {
        return driver;
    }
}
