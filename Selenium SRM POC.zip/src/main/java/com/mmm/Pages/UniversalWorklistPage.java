package com.mmm.Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UniversalWorklistPage {

    private WebDriver driver;
    private WebDriverWait wait;
    private String shoppingCart = "1001591816";
    private By showFilters = By.xpath("//a[@id='GMLJ.UWLMainView.CombinedTask__Advanced_Button']");
    private By scFilterInput = By.xpath("//input[@id='GMLJ.UWLMainView.Filter_subject']");
    private By scTableRow = By.xpath("//span[contains(.,"+shoppingCart+") and @id='GMLJ.UWLMainView.subject_LinkToAction.0-text']");

    //*[@id="GMLJ.UWLMainView.CombinedTask__Advanced_Button"]
    public UniversalWorklistPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, 30);
    }
    public void showFilters() {
        driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='contentAreaFrame']")));
        driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='ivuFrm_page0ivu1']")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(showFilters));
        driver.findElement(showFilters).click();
    }

    public void enterShoppingCart() {

        wait.until(ExpectedConditions.visibilityOfElementLocated(this.scFilterInput));
        WebElement scFilterInput = driver.findElement(this.scFilterInput);
        scFilterInput.sendKeys(shoppingCart);
        scFilterInput.sendKeys(Keys.ENTER);
    }

    public void selectShoppingCart() {
        wait.until(ExpectedConditions.elementToBeClickable(this.scTableRow));
        WebElement scRow = driver.findElement(this.scTableRow);
        retryingFindClick(scTableRow);
        //scRow.click();
    }

    private boolean retryingFindClick(By by) {
        boolean result = false;
        int attempts = 0;
        while(attempts < 2) {
            try {
                driver.findElement(by).click();
                result = true;
                break;
            } catch(StaleElementReferenceException e) {
            }
            attempts++;
        }
        return result;
    }
}
