package com.mmm.TestCases;

import com.mmm.Pages.LoginPage;
import com.mmm.Pages.ShoppingCartPage;
import com.mmm.Pages.UniversalWorklistPage;
import com.mmm.Pages.WebCommonServices;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.File;

public class ShoppingCartApprovalAndAdHoc {

    private DesiredCapabilities capabilities;
    private WebDriver driver;
    private WebCommonServices services;
    @BeforeClass
    private void setupDriver() {
        File file = new File("C:/TEMP/IEDriverServer.exe");
        System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
        this.services = WebCommonServices.getInstance();
        this.driver = this.services.getDriver();
/*        capabilities = DesiredCapabilities.internetExplorer();
        // commented because I have concern that this forces me log to SRM again when opening SC
        capabilities.setCapability("ensureCleanSession", true);
        capabilities.setCapability("enableElementCacheCleanup", true);
        capabilities.setCapability("nativeEvents", false);
        capabilities.setCapability("browserName", "internet explorer");
        capabilities.setCapability("ignoreZoomSetting", true);
        capabilities.setCapability("ignoreProtectedModeSettings", true);
        capabilities.setCapability("platform", Platform.WINDOWS);
        capabilities.setCapability("unexpectedAlertBehaviour", "accept");

        InternetExplorerOptions options = new InternetExplorerOptions(capabilities);
        driver = new InternetExplorerDriver(options);*/
    }

    @Test
    public void ShoppingCartApprovalAndAdHoc() {

        LoginPage login = new LoginPage(driver);
        UniversalWorklistPage worklist = new UniversalWorklistPage(driver);
        ShoppingCartPage scPage = new ShoppingCartPage(driver);

        login.openSRMLoginPage();
        login.loginToSRM();

        worklist.showFilters();
        worklist.enterShoppingCart();
        worklist.selectShoppingCart();

        services.getNewestWindow();
        if (login.checkIfLoginNeeded())
            login.loginToSRM();
        scPage.showDetailsOfItems();
        scPage.approveSC();

    }

}
